package local.hal.st31.androidjavaex.ex05;

/**
 * ST31 Android用java文法 サンプル Ex5 Src03
 *
 *AnimalInterfaceを使った実行クラス2
 *
 *05/22実行済み
 *
 * @author ohs85001
 *
 */

public class CallAnimals2 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		AnimalInterface cat = new AnimalInterface() {
			@Override
			public String getName() {
				return "たま";
			}

			@Override
			public String call() {
				return "にゃあ";
			}
		};
		print(cat);

		print(new AnimalInterface() {

			@Override
			public String getName() {
				return "とんこ";
			}
			@Override
			public String call() {
				return "ぶうぶう";
			}
		});
	}

	/**
	 * 動物の愛称とその鳴き声を表示するメソッド
	 *@param animal 動物
	 */

	private static void print(AnimalInterface animal) {
		System.out.println(animal.getName() + "：" + animal.call());
	}

}
