package local.hal.st31.androidjavaex.ex05;

/**
 * ST31 Android用java文法 サンプル Ex5 Src01
 *
 *動物を表すインターフェース
 *
 * @author ohs85001
 *
 */

public interface AnimalInterface {
	/**
	 *動物の愛称を得るメソッド
	 *@return 動物の愛称
	 */
	String getName();
	/**
	 *動物の鳴き声を得るメソッド
	 *@return 動物の鳴き声
	 */
	String call();

}
