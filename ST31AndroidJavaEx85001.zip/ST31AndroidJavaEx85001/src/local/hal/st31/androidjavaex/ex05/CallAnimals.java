package local.hal.st31.androidjavaex.ex05;

/**
 * ST31 Android用java文法 サンプル Ex5 Src02
 *
 *AnimalInterfaceを使った実行クラス
 *
 *05/22実行済み
 *
 * @author ohs85001
 *
 */

public class CallAnimals {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		Cat cat = new Cat();
		print(cat);

		print(new Pig());
	}

	/**
	 *をの愛称とその鳴き声を表示するメソッド
	 *@param animal 動物
	 */

	private static void print(AnimalInterface animal) {
		System.out.println(animal.getName() + "：" + animal.call());
	}

	/**
	 *猫を表すメンバクラス
	 */

	private static class Cat implements AnimalInterface {
		@Override
		public String getName() {
			return "たま";
		}

		@Override
		public String call() {
			return "にゃあ";
		}
	}
	/**
	 *豚を表すメンバクラス
	 */

	private static class Pig implements AnimalInterface {
		@Override
		public String getName() {
			return "とんこ";
		}

		@Override
		public String call() {
			return "ぶうぶう";
		}
	}

}
