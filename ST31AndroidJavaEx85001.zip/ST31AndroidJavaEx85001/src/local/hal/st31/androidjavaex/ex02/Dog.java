package local.hal.st31.androidjavaex.ex02;

/**
 * ST31 Android用java文法 サンプル Ex2 Src03
 *
 *犬を表すクラス
 *
 * @author ohs85001
 *
 */

public class Dog extends AbstractAnimal{
	@Override
	public String call() {
		return "わん、わん";
	}
}
