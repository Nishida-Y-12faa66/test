package local.hal.st31.androidjavaex.ex02;

/**
 * ST31 Android用java文法 サンプル Ex2 Src02
 *
 *猫を表すクラス
 *
 * @author ohs85001
 *
 */

public class Cat extends AbstractAnimal{
	@Override
	public String call() {
		return "にゃあ、にゃあ";
	}
}
