package local.hal.st31.androidjavaex.ex02;

/**
 * ST31 Android用java文法 サンプル Ex2 Src01
 *
 *抽象的な動物を表すクラス
 *
 * @author ohs85001
 *
 */

public abstract class AbstractAnimal {
	/**
	 *その動物の愛称を表すフィールド
	 */

	private String _name;

	/**
	 *愛称フィールドのセッタ
	 */

	public void setName(String name) {
		_name = name;
	}

	/**
	 *愛称フィールドのゲッタ
	 */

	public String getName() {
		return _name;
	}

	/**
	 *鳴き声のメソッド
	 *@return 鳴き声
	 */
	public abstract String call();
}
