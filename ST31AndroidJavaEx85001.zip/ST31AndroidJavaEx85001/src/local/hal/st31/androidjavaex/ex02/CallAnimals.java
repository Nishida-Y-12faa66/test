package local.hal.st31.androidjavaex.ex02;

/**
 * ST31 Android用java文法 サンプル Ex2 Src04
 *
 *実行クラス
 *
 *05/22 実行済み
 *
 * @author ohs85001
 *
 */

public class CallAnimals {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
//		AbstractAnimal pet = new AbstractAnimal();
//		pet.setName("動物");

		AbstractAnimal[] pets = new AbstractAnimal[2];

		pets[0] = new Cat();
		pets[1] = new Dog();

		pets[0].setName("たま");
		pets[1].setName("しろ");

		for (int i = 0; i < pets.length; i++) {
			String name = pets[i].getName();
			String call = pets[i].call();
			System.out.println(name + "：" + call);


		}
	}

}
