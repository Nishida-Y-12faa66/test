package local.hal.st31.androidjavaex.ex01;

/**
 * ST31 Android用java文法 サンプル Ex1 Src03
 *
 *猫を表すクラス
 *
 * @author ohs85001
 *
 */

public class Cat extends Animal{
	@Override
	public String call() {
		return "にゃあにゃあ";
	}
}
