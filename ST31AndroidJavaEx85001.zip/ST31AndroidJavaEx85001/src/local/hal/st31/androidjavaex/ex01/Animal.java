package local.hal.st31.androidjavaex.ex01;

/**
 * ST31 Android用java文法 サンプル Ex1 Src01
 *
 *動物を表すクラス
 *
 * @author ohs85001
 *
 */

public class Animal {
	/**
	 *その動物の愛称を表すフィールド
	 */
	private String _name;

	/**
	 *愛称フィールドのセッタ
	 */
	public void setName(String name) {
		_name = name;
	}

	/**
	 *愛称フィールドのゲッタ
	 */

	public String getName() {
		return _name;
	}

	/**鳴き声のメソッド
	 * ＠return 鳴き声
	 *
	 */

	public String call() {
		return "どんな鳴き声？";
	}

	/**
	 *お話しするメソッド。意味不明
	 */

	public void speak() {
		System.out.println("いえい！");
	}
}
