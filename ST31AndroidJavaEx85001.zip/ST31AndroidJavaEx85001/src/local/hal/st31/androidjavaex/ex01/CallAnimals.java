package local.hal.st31.androidjavaex.ex01;

/**
 * ST31 Android用java文法 サンプル Ex1 Src05
 *
 *実行クラス
 *
 *05/22 実行済み
 *
 * @author ohs85001
 *
 */

public class CallAnimals {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		Dog pet0 = new Dog();
		pet0.setName("ポチ");
		String name = pet0.getName();
		String call = pet0.call();
		System.out.println(name + ":" + call);
		System.out.println("------------");
		pet0.run();
		System.out.println("------------");

		Cat pet1 = new Cat();
		pet1.setName("たま");
		name = pet1.getName();
		call = pet1.call();
		System.out.println(name + ":" + call);
		System.out.println("------------");

		Pig pet2 = new Pig();
		pet2.setName("とんこ");
		name = pet2.getName();
		call = pet2.call();
		System.out.println(name + ":" + call);
		System.out.println("------------");
		pet2.eat();
		System.out.println("------------");
		pet2.speak();
	}

}
