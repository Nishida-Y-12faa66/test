package local.hal.st31.androidjavaex.ex01;

/**
 * ST31 Android用java文法 サンプル Ex1 Src02
 *
 *犬を表すクラス
 *
 * @author ohs85001
 *
 */

public class Dog extends Animal{
	/**
	 *走るメソッド
	 */

	public void run() {
		System.out.println("わんわん");
	}
}
