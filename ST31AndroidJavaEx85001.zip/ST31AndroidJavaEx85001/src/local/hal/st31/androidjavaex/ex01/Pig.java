package local.hal.st31.androidjavaex.ex01;

/**
 * ST31 Android用java文法 サンプル Ex1 Src04
 *
 *豚を表すクラス
 *
 * @author ohs85001
 *
 */

public class Pig extends Animal{
	@Override
	public String call() {
		return "ぶうぶう";
	}

	@Override
	public void speak() {
		super.speak();
		System.out.println("すばらしい！");
	}

	/**
	 *美味しいメソッド
	 */

	public void eat() {
		System.out.println("うまい！");
	}
}
