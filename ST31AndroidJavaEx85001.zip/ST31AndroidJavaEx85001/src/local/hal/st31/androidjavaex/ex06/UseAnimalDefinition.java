package local.hal.st31.androidjavaex.ex06;

/**
 * ST31 Android用java文法 サンプル Ex6 Src02
 *
 *AnimalDefinitionを使った実行クラス
 *
 *05/22実行済み
 *
 * @author ohs85001
 *
 */

public class UseAnimalDefinition {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		AnimalDefinition pigDef = new AnimalDefinition();
		pigDef.print(new Pig());

		AnimalDefinition dogDef = new AnimalDefinition();
		dogDef.print(new AnimalDefinition.AnimalInterface() {

			@Override
			public String getName() {
				return "ポチ";
			}

			@Override
			public String call() {
				return "わん、わん";
			}
		});
	}

	/**
	 *豚を表すメンバクラス
	 */

	private static class Pig implements AnimalDefinition.AnimalInterface {

		@Override
		public String getName() {
			return "とんこ";
		}

		@Override
		public String call() {
			return "ぶうぶう";
		}
	}

}
