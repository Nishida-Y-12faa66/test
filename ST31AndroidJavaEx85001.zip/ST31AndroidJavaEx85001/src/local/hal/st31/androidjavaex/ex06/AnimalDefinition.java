package local.hal.st31.androidjavaex.ex06;

/**
 * ST31 Android用java文法 サンプル Ex6 Src01
 *
 *動物を定義するクラス
 *
 * @author ohs85001
 *
 */

public class AnimalDefinition {
	/**
	 *動物を表すメンバインターフェース
	 */
	interface AnimalInterface {
		/**
		 *動物の愛称を得るメソッド
		 *@return 動物の愛称
		 */

		String getName();
		/**
		 *動物の鳴き声を得るメソッド
		 *@return 動物の鳴き声
		 */
		String call();
	}

	/**
	 *動物の内容を表示するメソッド
	 *@param animal 動物を表すメソッド
	 */

	public void print(AnimalInterface animal) {
		System.out.println(animal.getName() + "：" + animal.call());
	}
}
