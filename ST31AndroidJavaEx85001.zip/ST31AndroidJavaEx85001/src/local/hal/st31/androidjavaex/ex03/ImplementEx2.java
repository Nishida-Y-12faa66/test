package local.hal.st31.androidjavaex.ex03;

/**
 * ST31 Android用java文法 サンプル Ex3 Src03
 *
 *InterfaceExampleを実装したクラス2
 *
 * @author ohs85001
 *
 */

public class ImplementEx2  implements InterfaceExample {
	@Override
	public String getName() {
		return "私はImplementEx2です。";
	}

	@Override
	public int fooTimes() {
		return NUM * 25;
	}

	@Override
	public String getComment() {
		return "ImplementEx2のコメントだよん。";
	}

	@Override
	public void fooMethod() {}
}
