package local.hal.st31.androidjavaex.ex03;

/**
 * ST31 Android用java文法 サンプル Ex3 Src01
 *
 *インターフェースの例
 *
 * @author ohs85001
 *
 */

public interface InterfaceExample {
	/**
	 *とある定数
	 */

	int NUM = 200;

	/**
	 *名前を得るメソッド
	 *@return
	 */

	String getName();

	/**
	 *NUMの何倍かを得るメソッド。何倍かは実装クラスによって違う。
	 *@return NUMを何倍かした値を得るメソッド
	 */

	int fooTimes();

	/**
	 *このインターフェースを実装したクラスのコメントを得るメソッド
	 *@return	コメントを表す文字列
	 */

	String getComment();

	/**
	 *無意味なメソッド
	 */

	void fooMethod();
}
