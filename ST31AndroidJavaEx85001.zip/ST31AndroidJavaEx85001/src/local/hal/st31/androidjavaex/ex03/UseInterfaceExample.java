package local.hal.st31.androidjavaex.ex03;

/**
 * ST31 Android用java文法 サンプル Ex3 Src04
 *
 *InterfaceExampleを使った実行クラス
 *
 *05/22実行済み
 *
 * @author ohs85001
 *
 */

public class UseInterfaceExample {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
//		InterfaceExample interfaceEx = new InterfaceExample();

		ImplementEx1 ie1 = new ImplementEx1();
		ImplementEx2 ie2 = new ImplementEx2();
//		InterfaceExample ie1 = new ImplementEx1();
//		InterfaceExample ie2 = new ImplementEx2();

		print(ie1);
		print(ie2);

	}

	/**
	 *InterfaceExampleの各メソッドを処理するメソッド
	 *@param interEx InterfaceExampleを実装したクラス
	 */

	public static void print(InterfaceExample interEx) {
		System.out.println("-----表示します");
		String name = interEx.getName();
		int foo = interEx.fooTimes();
		String comment = interEx.getComment();

		System.out.println(name);
		System.out.println("fooTime=" + foo);
		System.out.println("コメント：" + comment);
	}

}
