package local.hal.st31.androidjavaex.ex04;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;


/**
 * ST31 Android用java文法 サンプル Ex4 Src01
 *
 *カクテルを表すクラス
 *
 * @author ohs85001
 *
 */

public class Cocktail {
	/**
	 * カクテルで使われる材料を表すクラス。
	 */

	private class Ingredient {
		/**
		 *1ml当たりの単価
		 */
		private double _price;
		/**
		 *材料名
		 */
		private String _name;
		/**
		 *分量
		 */
		private int _quantity;

		/**
		 *コンストラクタ
		 *
		 *@param name 材料名
		 *@param price 1ml当たりの単価
		 *@param quantity 分量
		 */
		public Ingredient (String name, double price, int quantity) {
			_name = name;
			_price = price;
			_quantity = quantity;
		}

		/**
		 *この材料のコストを計算するメソッド
		 *@return この材料のコスト
		 */

		public int getCost() {
			BigDecimal bigCost = new BigDecimal(_price * _quantity);
			bigCost = bigCost.setScale(0, RoundingMode.HALF_UP);
			return bigCost.intValue();
		}
	}

	/**
	 *材料リスト
	 */
	private ArrayList<Ingredient> _ingredients = new ArrayList<Ingredient>();

	/**カクテル名
	 *
	 */
	private String _name;

	/**
	 *コンストラクタ
	 *@param カクテル名
	 */
	public Cocktail(String name) {
		_name = name;
	}

	/**
	 *カクテルの材料を登録するメソッド
	 *@param name 材料名
	 *@param price 1ml当たりの単価
	 *@param quantity 分量
	 *
	 */
	public void addIngredient(String name, double price, int quantity) {
		Ingredient ingredient = new Ingredient(name, price, quantity);
		_ingredients.add(ingredient);
	}

	/**
	 *このカクテルのレシピを得るメソッド
	 *@return レシピを表す文字列
	 */
	public String getRecipe() {
		StringBuffer sb = new StringBuffer();
		sb.append(_name);
		sb.append("のレシピ:\n");
		for (Ingredient ing : _ingredients) {
			sb.append(ing._name);
			sb.append("：");
			sb.append(ing._quantity);
			sb.append("mm\t");
		}
		return sb.toString();

	}

	/**
	 *原価を計算するメソッド
	 *@return 計算された原価
	 */
	public int getCost() {
		int cost = 0;
		for (Ingredient ing : _ingredients) {
			cost += ing.getCost();
		}
		return cost;
	}

}
