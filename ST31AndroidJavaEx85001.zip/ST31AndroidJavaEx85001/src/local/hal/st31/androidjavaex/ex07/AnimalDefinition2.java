package local.hal.st31.androidjavaex.ex07;

/**
 * ST31 Android用java文法 サンプル Ex7 Src01
 *
 *動物を定義するクラス
 *
 * @author ohs85001
 *
 */

public class AnimalDefinition2 {
	/**
	 *動物を表すメンバインターフェース
	 */
	@FunctionalInterface
	interface AnimalInterface {
		/**
		 *動物の鳴き声を得るメソッド
		 *@param animal 動物
		 *@return 動物の鳴き声
		 */
		String call(String name);
	}

	/**
	 *動物の内容を表示するメソッド
	 *
	 *@param animal 動物の名前
	 *@return 動物を表すオブジェクト
	 */

	public void print(String name, AnimalInterface animal) {
		System.out.println(animal.call(name));
	}
}
