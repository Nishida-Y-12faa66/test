package local.hal.st31.androidjavaex.ex07;

/**
 * ST31 Android用java文法 サンプル Ex7 Src02
 *
 *AnimalDefinitionを使った実行クラス
 *
 *05/22実行済み
 *
 * @author ohs85001
 *
 */

public class UseAnimalDefinition2 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		AnimalDefinition2 dogDef =  new AnimalDefinition2();
		AnimalDefinition2.AnimalInterface dog =new AnimalDefinition2.AnimalInterface() {

			@Override
			public String call(String name) {
				return name + "の鳴き声はわん、わん";
			}
		};

		dogDef.print("犬", dog);
		AnimalDefinition2 catDef = new AnimalDefinition2();
		AnimalDefinition2.AnimalInterface cat = (String name) -> {
			return name + "の鳴き声はにゃあ、にゃあ";
		};
		catDef.print("猫", cat);
	}

}
